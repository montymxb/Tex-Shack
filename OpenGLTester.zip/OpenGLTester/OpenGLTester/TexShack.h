//
//  TexShack.h
//  Bit Shooter
//  Created by Benjamin Friedman (-mxb-) from www.UphouseWorks.com
//

#import <Foundation/Foundation.h>
#import <GLKit/GLKit.h>
#import "GLSquare.h"

@interface TexShack : NSObject
{
    @private
    GLuint *texIds;
    BOOL isRetina;
    BOOL isIPad;
    float curScale;
    float width;
    float height;
    float halfWidth;
    float halfHeight;
    GLSquare *texSquare;
    float genericSpacingRatio;
}

-(id)initWithScale: (float) scale screenWidth: (float) screenWidth screenHeight: (float) screenHeight;

-(CGImageRef)createCGImageRef:(NSString *)inputFile;

-(CGContextRef)makeContextWithSize:(CGSize)inSize;

-(GLuint)generateTexture: (CGImageRef) daImg;

-(GLuint)retrieveTextureWithCharacter: (char) c;

//-(void)drawCharacter: (char) c withX: (float) xx withY: (float) yy red: (float) red green: (float) green blue: (float) blue alpha: (float) alpha scale: (float) scalE matrix4: (GLKMatrix4) mvpMatrix matrixNormal: (GLKMatrix3) normalMatrix;

-(void)drawCharacters: (NSString *) c withX: (float) xx withY: (float) yy red: (float) red green: (float) green blue: (float) blue alpha: (float) alpha scale: (float) scalE matrix4: (GLKMatrix4) mvpMatrix matrixNormal: (GLKMatrix3) normalMatrix;

-(void)drawSquare:(GLSquare *)someSquare atX:(float)xCord atY:(float)yCord withScale: (float) scalE andMVP: (GLKMatrix4) mvpMatrix andNormal: (GLKMatrix3) normalMatrix ;

-(void)drawCharactersReverseAlign: (NSString *) c withX: (float) xx withY: (float) yy red: (float) red green: (float) green blue: (float) blue alpha: (float) alpha scale: (float) scalE matrix4: (GLKMatrix4) mvpMatrix matrixNormal: (GLKMatrix3) normalMatrix;

-(void)adjustXSpaceScale: (float) newXScale;

@end
