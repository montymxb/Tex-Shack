//
//  ViewLe.m
//  OpenGLTester
//

#import "ViewLe.h"

@implementation ViewLe

static int loadCounter;

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder: aDecoder];
    if(self)
    {
        loadCounter = 0;
        
        // Initialization code
        self.context = [[EAGLContext alloc] initWithAPI: kEAGLRenderingAPIOpenGLES2];
        [EAGLContext setCurrentContext:self.context];
        
        texShack = [[TexShack alloc] initWithScale: 1 screenWidth: [UIScreen mainScreen].bounds.size.width screenHeight: [UIScreen mainScreen].bounds.size.height];
        
        //you can setup a proper space adjustment mechanism for your app using the built-in adjustment
        [texShack adjustXSpaceScale: 1];
        
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glEnable(GL_BLEND);
    }
    return self;
}

-(void)drawRect:(CGRect)rect
{
    //timer object allocated
    //NSDate *timer = [[NSDate alloc] init];
    
    glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    [texShack drawCharacters: @"Dear Person who downloaded this project," withX: 300 withY: 50 red: 1 green: 1 blue: 1 alpha: 1 scale: 1 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    [texShack drawCharacters: @"Welcome to TexShack!" withX: 300 withY: 60 red: 0.1 green: 0.2 blue: 0.3 alpha: 1 scale: 1 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    [texShack drawCharacters: @"any combination of standard text, (a-z 0-9 and some keyboard symbols)" withX: 300 withY: 70 red: 0.8 green: 0.8 blue: 0.9 alpha: 0.9 scale: 0.9 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    [texShack drawCharacters: @"with RGBA values of your choice!" withX: 300 withY: 80 red: 0 green: 0.2 blue: 0.8 alpha: 0.5 scale: 0.9 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    [texShack drawCharactersReverseAlign: @"text can also be aligned on the other side" withX: 10 withY: 90 red: 0.5 green: 1 blue: 1 alpha: 1 scale: 0.9 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    [texShack drawCharacters: @"The characters ø & § are included, but still slightly buggy, use with care." withX: 315 withY: 110 red: 1 green: 1 blue: 0 alpha: 1 scale: 0.9 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    GLKMatrix4 modelViewMatrix = GLKMatrix4MakeRotation( -curDegrees,  100, 20, 30);
    _modelViewProjectionMatrix = GLKMatrix4Multiply( _modelViewProjectionMatrix, modelViewMatrix);
    
    [texShack drawCharacters: @"get fancy. With text like this." withX: 290 withY: 130 red: 1 green: 1 blue: 0 alpha: 1 scale: 1.1 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    modelViewMatrix = GLKMatrix4MakeRotation( curDegrees,  100, 20, 30);
    _modelViewProjectionMatrix = GLKMatrix4Multiply( _modelViewProjectionMatrix, modelViewMatrix);
    
    [texShack drawCharacters: @"I encourage you to tinker and improve upon this (very) basic work." withX: 315 withY: 150 red: 1 green: 1 blue: 0 alpha: 1 scale: 1 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    
    NSString *loadString;
    
    if(loadCounter < 15)
        loadString = @"ooo loading dots ->.";
    else if(loadCounter < 30)
        loadString = @"ooo loading dots ->...";
    else if(loadCounter < 45)
        loadString = @"ooo loading dots ->....";
    else if(loadCounter < 60)
        loadString = @"ooo loading dots ->.....";
    else if(loadCounter < 75)
        loadString = @"ooo loading dots ->......";
    else
        loadString = @"ooo loading dots ->.......";
    
    [texShack drawCharacters: loadString withX: 200 withY: 160 red: 0.2 green: 0.2 blue: 0.2 alpha: 1 scale: 1 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    
    [texShack drawCharacters: @"Here is a quick list of all available characters:" withX: 310 withY: 180 red: 1 green: 1 blue: 1 alpha: 1 scale: 1.4 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    [texShack drawCharacters: @"`1234567890-=~!@#$%^&*()_+" withX: 300 withY: 200 red: 0.1 green: 0.1 blue: 0.1 alpha: 1 scale: 1 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    [texShack drawCharacters: @"qwertyuiop[]\\QWERTYUIOP{}|" withX: 300 withY: 210 red: 0.1 green: 0.1 blue: 0.1 alpha: 1 scale: 1 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    [texShack drawCharacters: @"asdfghjkl;'ASDFGHJKL:\"" withX: 300 withY: 220 red: 0.1 green: 0.1 blue: 0.1 alpha: 1 scale: 1 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    [texShack drawCharacters: @"zxcvbnm,./ZXCVBNM<>?" withX: 300 withY: 230 red: 0.1 green: 0.1 blue: 0.1 alpha: 1 scale: 1 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    [texShack drawCharactersReverseAlign: @"If you got beef, go make a stew." withX: 20 withY: 250 red: 1 green: 1 blue: 0 alpha: 1 scale: 1 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    [texShack drawCharactersReverseAlign: @"Otherwise, enjoy!" withX: 20 withY: 260 red: 1 green: 1 blue: 0 alpha: 1 scale: 1 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    [texShack drawCharacters: @"PS: Global spacing inbetween characters can be adjusted as well," withX: 300 withY: 280 red: 0.5 green: 0.1 blue: 0.1 alpha: 1 scale: 1 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    [texShack drawCharacters: @"in case they look a bit too close." withX: 300 withY: 290 red: 0.5 green: 0.1 blue: 0.1 alpha: 1 scale: 1 matrix4: _modelViewProjectionMatrix matrixNormal: _normalMatrix];
    
    
    [self performSelectorInBackground: @selector(update) withObject: nil];
    
    //timer object nslogged and released, this gives you rough FPS estimate on the fly while working
    //NSLog(@"%f", [timer timeIntervalSinceNow] * -1000);
    //[timer release];
}


-(void)update
{
    
    float aspect = fabsf(self.bounds.size.width / self.bounds.size.height);
    
    GLKMatrix4 projectionMatrix = GLKMatrix4MakePerspective(GLKMathDegreesToRadians(65.0f), aspect, 0.1f, 100.0f);
    GLKMatrix4 baseModelViewMatrix = GLKMatrix4MakeTranslation(0, 0, -4.0f);
    
    // Compute the model view matrix for the object rendered with ES2
    GLKMatrix4 modelViewMatrix = GLKMatrix4MakeTranslation(0, 0, 1.5f);
    modelViewMatrix = GLKMatrix4Multiply(baseModelViewMatrix, modelViewMatrix);
    
    
    _normalMatrix = GLKMatrix3InvertAndTranspose(GLKMatrix4GetMatrix3(modelViewMatrix), NULL);
    _modelViewProjectionMatrix = GLKMatrix4Multiply(projectionMatrix, modelViewMatrix);
    
    if(curDegrees > 100)
        curDegrees = -100;
    
    curDegrees+=0.1;
    
    loadCounter+=2;
    if(loadCounter > 90)
        loadCounter = 0;
}

-(void)dealloc
{
    [texShack release];
    [super dealloc];
}


@end
