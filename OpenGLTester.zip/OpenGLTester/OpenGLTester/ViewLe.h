//
//  ViewLe.h
//  OpenGLTester
//
//

#import <GLKit/GLKit.h>
#import "TexShack.h"

@interface ViewLe : GLKView
{
    GLKMatrix4 _modelViewProjectionMatrix;
    GLKMatrix3 _normalMatrix;
    TexShack *texShack;
    float curDegrees;
}
@property (strong, nonatomic) EAGLContext *context;

@end
