//
//  ViewController.m
//  OpenGLTester
//
//

#import "ViewController.h"


@implementation ViewController

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder: aDecoder];
    if(self)
    {
    }
    return self;
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    self.preferredFramesPerSecond = 60;
    
}

@end
