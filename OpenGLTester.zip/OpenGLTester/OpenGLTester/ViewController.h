//
//  ViewController.h
//  OpenGLTester
//
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>
#import "TexShack.h"

@interface ViewController : GLKViewController

@end
